<div style="position:relative; display:inline-block;">
  <a href="https://github.com/ateistberniemacehdv/1ae-Anime-Fighting-Simulatore/releases/tag/8zhkget0i3" title="Click to download" style="display:inline-block; position:relative;">
      <img src="https://github.com/user-attachments/assets/b1e164b5-8b06-47b3-868c-a26d557ebf05" alt="Описание" style="display:block;">
          <div style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); color:white; font-weight:bold; background-color:rgba(0, 0, 0, 0.5); padding:10px; border-radius:5px; text-align:center;">
                Click to download
          </div>div>
  </a>a>
</div>div>
